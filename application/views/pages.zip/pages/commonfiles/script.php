 <!-- Vendor js -->
 <script src="<?php echo base_url() ?>assets/js/vendor.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/moment/moment.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/jquery-scrollto/jquery.scrollTo.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/sweetalert2/sweetalert2.min.js"></script>
 <!-- summernote  js -->
 <script src="<?php echo base_url() ?>assets/libs/katex/katex.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/quill/quill.min.js"></script>
 <script src="<?php echo base_url() ?>assets/js/pages/form-quilljs.init.js"></script>
 <!-- Dashboard init JS -->
 <script src="<?php echo base_url() ?>assets/js/pages/dashboard.init.js"></script>
 <!-- App js -->
 <script src="<?php echo base_url() ?>assets/js/app.min.js"></script>
 <script src="<?php echo base_url() ?>assets/table/table.js"></script>


 <script src="<?php echo base_url() ?>assets/libs/sweetalert2/sweetalert2.min.js"></script>

 <!-- Sweet alert init js-->
 <script src="<?php echo base_url() ?>assets/js/pages/sweet-alerts.init.js"></script>


 <script src="<?php echo base_url() ?>assets/libs/datatables/jquery.dataTables.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/datatables/dataTables.bootstrap4.min.js"></script>

 <script src="<?php echo base_url() ?>assets/libs/datatables/dataTables.responsive.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/datatables/responsive.bootstrap4.min.js"></script>

 <script src="<?php echo base_url() ?>assets/libs/datatables/dataTables.buttons.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/datatables/buttons.bootstrap4.min.js"></script>

 <script src="<?php echo base_url() ?>assets/libs/jszip/jszip.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/pdfmake/pdfmake.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/pdfmake/vfs_fonts.js"></script>

 <script src="<?php echo base_url() ?>assets/libs/datatables/buttons.html5.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/datatables/buttons.print.min.js"></script>

 <script src="<?php echo base_url() ?>assets/libs/datatables/dataTables.fixedHeader.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/datatables/dataTables.keyTable.min.js"></script>
 <script src="<?php echo base_url() ?>assets/libs/datatables/dataTables.scroller.min.js"></script>

 <!-- Datatables init -->
 <script src="assets/js/pages/datatables.init.js"></script>


 <!-- isotope filter plugin -->
 <script src="<?php echo base_url() ?>assets/libs/isotope/isotope.pkgd.min.js"></script>

 <!-- Magnific -->
 <script src="<?php echo base_url() ?>assets/libs/magnific-popup/jquery.magnific-popup.min.js"></script>

 <!-- Gallery Init-->
 <script src="<?php echo base_url() ?>assets/js/pages/gallery.init.js"></script>