<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'commonfiles/link.php' ?>
</head>

<body>

    <!-- Begin page -->
    <div id="wrapper">

        <!-- Topbar Star t -->
        <?php include 'commonfiles/header.php' ?>
        <!-- end Topbar -->

        <!--  Left Sidebar Start -->
        <?php include 'commonfiles/sidebar.php' ?>
        <!-- Left Sidebar End -->

        <!-- Start Page Content here -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <!-- <h4 class="page-title">User Managemnt</h4> -->
                                <div class="page-title-right">
                                    <ol class="breadcrumb p-0 m-0">
                                        <li class="breadcrumb-item"><a
                                                href="<?php echo base_url('dashboard') ?>">Dashboard</a></li>
                                        <li class="breadcrumb-item active">Order Managemnt</li>
                                    </ol>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">Ongoing Orders</h3>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="table-responsive">
                                                 <table id="datatable" class="table table-striped table-bordered table-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                                    <thead>
                                                        <tr>
                                                            <th>Sr No</th>
                                                            <th>Order ID</th>
                                                            <th>Order Date | Time</th>
                                                            <th>Customer </th>
                                                            <th>Vendor </th>
                                                            <th>Mobile</th>
                                                            <th>Amount</th>
                                                            <th>Order Status</th>
                                                            <th>Payment Status</th>
                                                            <th>Order Details</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>1</td>
                                                            <td>
                                                                <span> #12321</span>
                                                            </td>
                                                            <td>
                                                                <span>13 May 2024 11:00am</span>
                                                            </td>
                                                            <td>
                                                                <span>Jay Belkar</span>
                                                            </td>
                                                            <td>
                                                                <span>Raj Sharma</span>
                                                            </td>
                                                            <td>9878786765</td>

                                                            <td>
                                                                <span>SAR 40</span>
                                                            </td>
                                                            <td>
                                                                <span class="text-warning">ongoing</span>
                                                            </td>
                                                            <td>
                                                                <span class="text-danger fw-bold"> Pending</span>
                                                            </td>

                                                            <td><a href="<?php echo base_url('order_details')?>"
                                                                    class="btn btn-success btn-sm"><i
                                                                        class=" fa fa-shopping-cart"
                                                                        aria-hidden="true"></i></a>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>1</td>
                                                            <td>
                                                                <span> #12321</span>
                                                            </td>
                                                            <td>
                                                                <span>13 May 2024 11:00am</span>
                                                            </td>
                                                            <td>
                                                                <span>Jay Belkar</span>
                                                            </td>
                                                            <td>
                                                                <span>Ajay Sharma</span>
                                                            </td>
                                                            <td>8767676767</td>

                                                            <td>
                                                                <span> SAR 30</span>
                                                            </td>
                                                            <td>
                                                                <span class="text-warning">ongoing</span>
                                                            </td>
                                                            <td>
                                                                <span class="text-danger fw-bold"> Pending</span>
                                                            </td>

                                                            <td><a href="<?php echo base_url('order_details')?>"
                                                                    class="btn btn-success btn-sm"><i
                                                                        class=" fa fa-shopping-cart"
                                                                        aria-hidden="true"></i></a>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>


                </div>
                <!-- end container-fluid -->

            </div>

            <!-- end content -->

            <!-- Footer Start -->
            <?php include 'commonfiles/footer.php' ?>
            <!-- end Footer -->

        </div>

        <!-- End Page content -->

    </div>
    <!-- END wrapper -->

    <!-- Right bar overlay-->
    <div class="rightbar-overlay"></div>

    <?php include 'commonfiles/script.php' ?>

</body>

</html>