    <footer class="footer">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2024 Laundry. All rights reserved.Powerd By
                    <a href="#"><b>Appzia Technologies</b></a>
                </div>
            </div>
        </div>
    </footer>