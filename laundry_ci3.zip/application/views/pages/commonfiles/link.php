<meta charset="utf-8" />
<title>WASH DASH</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta content="" name="description" />
<meta content="Coderthemes" name="author" />
<meta http-equiv="X-UA-Compatible" content="IE=edge" />
<!-- App favicon -->
<link rel="shortcut icon" href="<?php echo base_url() ?>assets/images/favicon.ico">
<!-- Plugins css-->
<link href="<?php echo base_url() ?>assets/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />
<!-- summernote  -->
<link href="<?php echo base_url() ?>assets/libs/quill/quill.core.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url() ?>assets/libs/quill/quill.bubble.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url() ?>assets/libs/quill/quill.snow.css" rel="stylesheet" type="text/css" />
<!-- App css -->
<link href="<?php echo base_url() ?>assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" id="bootstrap-stylesheet" />
<link href="<?php echo base_url() ?>assets/css/icons.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url() ?>assets/css/app.min.css" rel="stylesheet" type="text/css" id="app-stylesheet" />
<link href="<?php echo base_url() ?>assets/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />



<!-- Table datatable css -->
<link href="<?php echo base_url() ?>assets/libs/datatables/dataTables.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url() ?>assets/libs/datatables/buttons.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url() ?>assets/libs/datatables/fixedHeader.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url() ?>assets/libs/datatables/responsive.bootstrap4.min.css" rel="stylesheet" type="text/css" />
<link href="<?php echo base_url() ?>assets/libs/datatables/scroller.bootstrap4.min.css" rel="stylesheet" type="text/css" />


  <!-- Magnific -->
  <link rel="stylesheet" href="<?php echo base_url() ?>assets/libs/magnific-popup/magnific-popup.css" />