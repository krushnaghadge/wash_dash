<!DOCTYPE html>
<html lang="en">

<head>
    <?php include 'commonfiles/link.php' ?>
</head>

<body>

    <!-- Begin page -->
    <div id="wrapper">

        <!-- Topbar Star t -->
        <?php include 'commonfiles/header.php' ?>
        <!-- end Topbar -->

        <!--  Left Sidebar Start -->
        <?php include 'commonfiles/sidebar.php' ?>
        <!-- Left Sidebar End -->

        <!-- Start Page Content here -->

        <div class="content-page">
            <div class="content">

                <!-- Start Content-->
                <div class="container-fluid">

                    <!-- start page title -->
                    <div class="row">
                        <div class="col-12">
                            <div class="page-title-box">
                                <!-- <h4 class="page-title">User Managemnt</h4> -->
                                <div class="page-title-right">
                                    <ol class="breadcrumb p-0 m-0">
                                        <li class="breadcrumb-item"><a
                                                href="<?php echo base_url('dashboard') ?>">Dashboard</a></li>
                                        <li class="breadcrumb-item active">User Managemnt</li>
                                    </ol>
                                </div>
                                <div class="clearfix"></div>
                            </div>
                        </div>
                    </div>
                    <!-- end page title -->

                    <div class="row">
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-header">
                                    <h3 class="card-title">New Orders</h3>
                                </div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-12">
                                            <div class="table-responsive">
                                                 <table id="datatable" class="table table-striped table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                                                    <thead>
                                                        <tr>
                                                            <th>Sr No</th>
                                                            <th>Order ID</th>
                                                            <th>Order Date | Time</th>
                                                            <th>Customer </th>
                                                            <th>Amount</th>
                                                            <th>Order Status</th>
                                                            <th>Payment Status</th>
                                                            <th>Assign Order</th>
                                                            <th>Order Details</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <td>1</td>
                                                            <td>
                                                                <span> #12321</span>
                                                            </td>
                                                            <td>
                                                                <span>13 May 2024 11:00am</span>
                                                            </td>
                                                            <td>
                                                                <span>Jay Belkar</span>
                                                            </td>

                                                            <td>
                                                                <span>₹300</span>
                                                            </td>
                                                            <td>
                                                                <select name="" id="" class="form-control">
                                                                    <option value="" selected>Pending</option>
                                                                    <option value="">Accepted</option>
                                                                    <option value="">Cancelled</option>

                                                                </select>
                                                            </td>
                                                            <td>
                                                                <span class="text-danger fw-bold"> Pending</span>
                                                            </td>
                                                            <td>


                                                                <a data-target="#add-modal" data-toggle="modal"
                                                                    class="btn btn-info btn-sm waves-effect waves-light">
                                                                    <i class="fa fa-tasks" aria-hidden="true"></i>
                                                                </a>
                                                            </td>
                                                            <td><a href="<?php echo base_url('order_details')?>"
                                                                    class="btn btn-success btn-sm"><i
                                                                        class=" fa fa-shopping-cart"
                                                                        aria-hidden="true"></i></a>
                                                            </td>
                                                        </tr>
                                                        <tr>
                                                            <td>1</td>
                                                            <td>
                                                                <span> #12321</span>
                                                            </td>
                                                            <td>
                                                                <span>13 May 2024 11:00am</span>
                                                            </td>
                                                            <td>
                                                                <span>Jay Belkar</span>
                                                            </td>

                                                            <td>
                                                                <span>₹300</span>
                                                            </td>
                                                            <td>
                                                                <select name="" id="" class="form-control">
                                                                    <option value="" selected>Pending</option>
                                                                    <option value="">Accepted</option>
                                                                    <option value="">Cancelled</option>

                                                                </select>
                                                            </td>
                                                            <td>
                                                                <span class="text-danger fw-bold"> Pending</span>
                                                            </td>
                                                            <td>
                                                                <a data-target="#add-modal" data-toggle="modal"
                                                                    class="btn btn-info btn-sm waves-effect waves-light">
                                                                    <i class="fa fa-tasks" aria-hidden="true"></i>
                                                                </a>
                                                            </td>
                                                            <td><a href="<?php echo base_url('order_details')?>"
                                                                    class="btn btn-success btn-sm"><i
                                                                        class=" fa fa-shopping-cart"
                                                                        aria-hidden="true"></i></a>
                                                            </td>
                                                        </tr>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div id="add-modal" class="modal fade " tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                        aria-modal="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title">Assign Order to Vendor</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">×</span>
                                    </button>
                                </div>
                                <form>
                                    <div class="modal-body">
                                        <div class="col-lg-12">

                                            <div class="radio radio-info form-check-inline">
                                                <input type="radio" id="inlineRadio1" value="option1" name="radioInline"
                                                    checked="checked">
                                                <label for="inlineRadio1"> Jay Belkar </label>
                                            </div>
                                            <div class="radio form-check-inline">
                                                <input type="radio" id="inlineRadio2" value="option2"
                                                    name="radioInline">
                                                <label for="inlineRadio2"> Avani Belkar </label>
                                            </div>
                                            <div class="radio form-check-inline">
                                                <input type="radio" id="inlineRadio3" value="option3"
                                                    name="radioInline">
                                                <label for="inlineRadio3"> Ashok Varma </label>
                                            </div>
                                            <div class="radio form-check-inline">
                                                <input type="radio" id="inlineRadio4" value="option4"
                                                    name="radioInline">
                                                <label for="inlineRadio4"> Manoj Sharma </label>
                                            </div>
                                        </div>



                                    </div>
                                    <div class="modal-footer">

                                        <button type="submit" class="btn btn-info waves-effect waves-light">
                                            Send</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- end container-fluid -->

            </div>

            <!-- end content -->

            <!-- Footer Start -->
            <?php include 'commonfiles/footer.php' ?>
            <!-- end Footer -->

        </div>

        <!-- End Page content -->

    </div>
    <!-- END wrapper -->

    <!-- Right bar overlay-->
    <div class="rightbar-overlay"></div>

    <?php include 'commonfiles/script.php' ?>

</body>

</html>